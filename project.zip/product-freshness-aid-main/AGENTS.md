<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Use the Blush & Lavender semantic token system with Sora headings, Manrope body text, and bento-style operational layouts to keep the inventory workspace distinctive and consistent.
- Keep wallpaper presentation settings in a dedicated toolbar control so visual preferences stay separate from inventory workflows.
