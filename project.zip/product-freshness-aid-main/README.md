# Fresh Tracks

Build a modern, responsive "Product Shelf-Life & Inventory Tracker" web app using Next.js (App Router), React, TypeScript, Tailwind CSS, Lucide React icons, and Recharts.

### Core Features & Functionality:

1. **Dashboard & Expiration Health Summary:**

   - Top KPI metric cards displaying:

     - Total Products in Stock

     - Active / Safe Products (Green badge)

     - Near Expiration (e.g., expiring within 7, 15, or 30 days — Yellow badge)

     - Expired Products (Red badge)

   - Visual summary charts (e.g., Expiration Breakdown pie chart or upcoming expiration timeline).

2. **Inventory Management & Data Upload:**

   - **Manual Add/Edit Form:** Modal or slide-over to add/edit products with inputs for:

     - Product Name, Category/SKU, Quantity (Stock level), Unit (e.g., pcs, kg, boxes)

     - Manufactured Date (`YYYY-MM-DD`)

     - Expiry Date (`YYYY-MM-DD`)

     - Alert Threshold (e.g., notify X days before expiry; default 30 days)

   - **Bulk CSV / Excel Upload:**

     - Integrated drag-and-drop file upload using `papaparse` (or custom CSV parser) to bulk-import stock data (`Product Name, SKU, Quantity, Mfg Date, Expiry Date`).

     - Validation & preview step showing successful rows and parsing errors before final import.

3. **Smart Notification & Alert System:**

   - **In-App Notification Bell & Center:**

     - Badge displaying total active alerts (Expired + Near Expiry).

     - Filter notifications by critical level: "Expired" vs. "Expiring Soon".

     - Option to mark notifications as read or dismiss them.

   - **Browser Web Notifications:**

     - Toggle to enable native browser notifications (`Notification.requestPermission()`) when entering the app if any products are expired or expiring within the threshold.

4. **Product Table & Filtering:**

   - Search bar by product name or SKU.

   - Filters by Status: "All", "Expired", "Expiring Soon (<30 Days)", "Healthy/Safe".

   - Sortable columns: Product Name, Stock Quantity, Manufactured Date, Expiry Date, Days Remaining.

   - Status Indicator Badges:

     - **Expired:** Red status badge showing "Expired X days ago".

     - **Near Expiry:** Amber/Yellow badge showing "Expires in X days".

     - **Safe:** Green badge with exact days remaining.

   - Action buttons per row: Edit, Delete, Adjust Stock Quantity (`+`/`-`).

5. **Data Persistence & Export:**

   - Persist product data in `localStorage` by default (or clean state fallback) so data remains after refresh.

   - "Export to CSV" button to download current inventory status.

   - Provide a "Load Sample Data" button with realistic perishable items (e.g., dairy, pharmaceuticals, packaged goods) for instant demo testing.

### Technical Guidelines:

- Project structure:

  - `src/types/inventory.ts` (Type interfaces for Product, Notification, FilterOptions)

  - `src/components/Dashboard.tsx`

  - `src/components/ProductTable.tsx`

  - `src/components/ProductModal.tsx`

  - `src/components/NotificationCenter.tsx`

  - `src/components/CsvUploader.tsx`

  - `src/utils/dateUtils.ts` (Calculations for days remaining, status checks, date formatting)

- Ensure clean visual design using modern Tailwind styles, dark/light contrast, and clear warning colors.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://product-freshness-aid.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6b653596-acd0-50d4-b55d-761f2e7f2702).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
