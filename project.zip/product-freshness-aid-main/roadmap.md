# Roadmap

- [x] Redesign the interface with soft pastel colors and gentle animated visuals.
- [x] Add a wide horizontal supermarket picture animated gently from left to right as a subtle background watermark.
- [x] Implement the pastel glass bento direction.
- [ ] Add wallpaper opacity, speed, and pause controls.
