import { useRef, useState } from "react";
import Papa from "papaparse";
import { AlertTriangle, CheckCircle2, FileSpreadsheet, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { ParsedRow, Product, ProductUnit } from "@/types/inventory";
import { normaliseDate } from "@/utils/dateUtils";
import { newId } from "@/utils/inventoryStore";
import { cn } from "@/lib/utils";

const UNITS: ProductUnit[] = ["pcs", "kg", "g", "L", "boxes", "packs"];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (products: Product[]) => void;
}

function pick(row: Record<string, string>, keys: string[]): string {
  for (const key of Object.keys(row)) {
    const norm = key.trim().toLowerCase().replace(/[\s_.]+/g, " ");
    if (keys.includes(norm)) return (row[key] ?? "").trim();
  }
  return "";
}

function toRow(raw: Record<string, string>, index: number): ParsedRow {
  const errors: string[] = [];
  const name = pick(raw, ["product name", "product", "name", "item"]);
  const sku = pick(raw, ["sku", "code", "category/sku", "product code"]);
  const category = pick(raw, ["category", "type"]);
  const qtyRaw = pick(raw, ["quantity", "qty", "stock", "stock quantity"]);
  const unitRaw = pick(raw, ["unit", "uom", "units"]).toLowerCase();
  const mfgRaw = pick(raw, ["mfg date", "manufactured date", "manufacture date", "mfg"]);
  const expRaw = pick(raw, ["expiry date", "expiration date", "expiry", "exp date", "best before"]);
  const thresholdRaw = pick(raw, ["alert threshold", "threshold", "alert days"]);

  if (!name) errors.push("Missing product name");
  const quantity = Number(qtyRaw || "0");
  if (!Number.isFinite(quantity) || quantity < 0) errors.push(`Invalid quantity "${qtyRaw}"`);
  const mfgDate = normaliseDate(mfgRaw);
  if (!mfgDate) errors.push(`Invalid manufactured date "${mfgRaw}"`);
  const expiryDate = normaliseDate(expRaw);
  if (!expiryDate) errors.push(`Invalid expiry date "${expRaw}"`);
  if (mfgDate && expiryDate && expiryDate < mfgDate) errors.push("Expiry before manufacture date");

  const unit = (UNITS.find((u) => u.toLowerCase() === unitRaw) ?? "pcs") as ProductUnit;
  const threshold = Number(thresholdRaw);

  return {
    row: index + 2,
    raw,
    errors,
    product:
      errors.length === 0
        ? {
            id: newId(),
            createdAt: new Date().toISOString(),
            name,
            sku: (sku || name.slice(0, 6).toUpperCase().replace(/\s/g, "")).toUpperCase(),
            category: category || "Uncategorised",
            quantity,
            unit,
            mfgDate: mfgDate!,
            expiryDate: expiryDate!,
            alertThreshold: Number.isFinite(threshold) && threshold > 0 ? threshold : 30,
          }
        : null,
  };
}

export function CsvUploader({ open, onOpenChange, onImport }: Props) {
  const [rows, setRows] = useState<ParsedRow[] | null>(null);
  const [fileName, setFileName] = useState("");
  const [dragging, setDragging] = useState(false);
  const [fatal, setFatal] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function reset() {
    setRows(null);
    setFileName("");
    setFatal(null);
  }

  function handleFile(file: File) {
    setFatal(null);
    setFileName(file.name);
    if (!/\.(csv|txt|tsv)$/i.test(file.name)) {
      setRows(null);
      setFatal(
        "Only CSV files can be parsed in the browser. Export your spreadsheet as CSV and try again.",
      );
      return;
    }
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const data = result.data.filter((r) =>
          Object.values(r).some((v) => (v ?? "").toString().trim() !== ""),
        );
        if (data.length === 0) {
          setRows([]);
          setFatal("No data rows found in this file.");
          return;
        }
        setRows(data.map(toRow));
      },
      error: (err) => setFatal(err.message),
    });
  }

  const valid = rows?.filter((r) => r.product) ?? [];
  const invalid = rows?.filter((r) => !r.product) ?? [];

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) reset();
        onOpenChange(v);
      }}
    >
      <DialogContent className="max-h-[90vh] gap-0 overflow-hidden p-0 sm:max-w-2xl">
        <DialogHeader className="border-b border-border p-5">
          <DialogTitle>Bulk import inventory</DialogTitle>
          <DialogDescription>
            CSV columns: Product Name, SKU, Quantity, Unit, Mfg Date, Expiry Date, Alert
            Threshold.
          </DialogDescription>
        </DialogHeader>

        <div className="max-h-[60vh] space-y-4 overflow-y-auto p-5">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFile(file);
            }}
            onClick={() => inputRef.current?.click()}
            className={cn(
              "flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors",
              dragging ? "border-primary bg-accent/40" : "border-border hover:bg-secondary/60",
            )}
          >
            <UploadCloud className="size-8 text-muted-foreground" />
            <p className="mt-3 text-sm font-medium">Drag & drop your CSV here</p>
            <p className="mt-1 text-xs text-muted-foreground">or click to browse files</p>
            {fileName && (
              <p className="num mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                <FileSpreadsheet className="size-3.5" />
                {fileName}
              </p>
            )}
            <input
              ref={inputRef}
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFile(file);
                e.target.value = "";
              }}
            />
          </div>

          {fatal && (
            <p className="rounded-lg border border-danger/25 bg-danger-soft px-3 py-2 text-sm text-danger">
              {fatal}
            </p>
          )}

          {rows && rows.length > 0 && (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-safe/25 bg-safe-soft px-3 py-2.5 text-sm text-safe">
                  <CheckCircle2 className="mr-1.5 inline size-4" />
                  <span className="num font-semibold">{valid.length}</span> rows ready to import
                </div>
                <div className="rounded-lg border border-warn/35 bg-warn-soft px-3 py-2.5 text-sm text-warn-foreground">
                  <AlertTriangle className="mr-1.5 inline size-4" />
                  <span className="num font-semibold">{invalid.length}</span> rows with errors
                </div>
              </div>

              {invalid.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                    Parsing errors
                  </p>
                  {invalid.slice(0, 8).map((r) => (
                    <p key={r.row} className="text-xs text-danger">
                      Row {r.row}: {r.errors.join(", ")}
                    </p>
                  ))}
                  {invalid.length > 8 && (
                    <p className="text-xs text-muted-foreground">
                      …and {invalid.length - 8} more rows with errors
                    </p>
                  )}
                </div>
              )}

              {valid.length > 0 && (
                <div className="overflow-hidden rounded-lg border border-border">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-secondary/60 text-left text-muted-foreground">
                        <th className="px-3 py-2">Product</th>
                        <th className="px-3 py-2">SKU</th>
                        <th className="px-3 py-2">Qty</th>
                        <th className="px-3 py-2">Mfg</th>
                        <th className="px-3 py-2">Expiry</th>
                      </tr>
                    </thead>
                    <tbody>
                      {valid.slice(0, 10).map((r) => (
                        <tr key={r.row} className="border-t border-border/70">
                          <td className="px-3 py-2 font-medium">{r.product!.name}</td>
                          <td className="num px-3 py-2">{r.product!.sku}</td>
                          <td className="num px-3 py-2">
                            {r.product!.quantity} {r.product!.unit}
                          </td>
                          <td className="num px-3 py-2">{r.product!.mfgDate}</td>
                          <td className="num px-3 py-2">{r.product!.expiryDate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {valid.length > 10 && (
                    <p className="border-t border-border bg-secondary/40 px-3 py-2 text-xs text-muted-foreground">
                      Previewing 10 of {valid.length} valid rows.
                    </p>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <DialogFooter className="border-t border-border p-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={valid.length === 0}
            onClick={() => {
              onImport(valid.map((r) => r.product!));
              reset();
              onOpenChange(false);
            }}
          >
            Import {valid.length > 0 ? valid.length : ""} products
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
