import { useMemo } from "react";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AlertTriangle, Boxes, CheckCircle2, XCircle } from "lucide-react";
import type { Product } from "@/types/inventory";
import { daysRemaining, getStatus } from "@/utils/dateUtils";
import { cn } from "@/lib/utils";

interface Props {
  products: Product[];
}

const buckets = [
  { label: "≤ 7 d", max: 7 },
  { label: "8–15 d", max: 15 },
  { label: "16–30 d", max: 30 },
  { label: "31–90 d", max: 90 },
  { label: "90 d +", max: Infinity },
];

export function Dashboard({ products }: Props) {
  const stats = useMemo(() => {
    let expired = 0;
    let expiring = 0;
    let safe = 0;
    let units = 0;
    for (const p of products) {
      units += Number(p.quantity) || 0;
      const s = getStatus(p);
      if (s === "expired") expired += 1;
      else if (s === "expiring") expiring += 1;
      else safe += 1;
    }
    return { expired, expiring, safe, units };
  }, [products]);

  const pieData = [
    { name: "Safe", value: stats.safe, fill: "var(--color-safe)" },
    { name: "Near expiry", value: stats.expiring, fill: "var(--color-warn)" },
    { name: "Expired", value: stats.expired, fill: "var(--color-danger)" },
  ].filter((d) => d.value > 0);

  const timeline = useMemo(() => {
    const rows = buckets.map((b) => ({ label: b.label, count: 0 }));
    for (const p of products) {
      const d = daysRemaining(p.expiryDate);
      if (d < 0) continue;
      const idx = buckets.findIndex((b) => d <= b.max);
      const row = idx >= 0 ? rows[idx] : undefined;
      if (row) row.count += 1;
    }
    return rows;
  }, [products]);

  const kpis = [
    {
      label: "Total products in stock",
      value: products.length,
      hint: `${stats.units.toLocaleString()} units tracked`,
      icon: Boxes,
      tone: "bg-secondary text-secondary-foreground border-border",
    },
    {
      label: "Active / safe",
      value: stats.safe,
      hint: "Beyond alert threshold",
      icon: CheckCircle2,
      tone: "bg-safe-soft text-safe border-safe/25",
    },
    {
      label: "Near expiration",
      value: stats.expiring,
      hint: "Within alert threshold",
      icon: AlertTriangle,
      tone: "bg-warn-soft text-warn-foreground border-warn/35",
    },
    {
      label: "Expired",
      value: stats.expired,
      hint: "Remove from shelf",
      icon: XCircle,
      tone: "bg-danger-soft text-danger border-danger/25",
    },
  ];

  return (
    <section className="grid grid-cols-1 gap-4 lg:grid-cols-12">
      <div className="grid gap-4 sm:grid-cols-2 lg:col-span-12 xl:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="panel panel-enter overflow-hidden p-5">
            <div className="flex items-start justify-between gap-3">
              <p className="text-sm text-muted-foreground">{k.label}</p>
              <span
                className={cn(
                  "inline-flex size-9 items-center justify-center rounded-lg border",
                  k.tone,
                )}
              >
                <k.icon className="size-4" />
              </span>
            </div>
            <p className="num mt-3 text-4xl leading-none font-semibold">{k.value}</p>
            <p className="mt-2 text-xs text-muted-foreground">{k.hint}</p>
          </div>
        ))}
      </div>

      <div className="contents">
        <div className="panel panel-enter p-5 lg:col-span-5">
          <h3 className="text-base font-semibold">Expiration breakdown</h3>
          <p className="mt-1 text-xs text-muted-foreground">Share of SKUs by shelf status</p>
          <div className="h-60">
            {pieData.length === 0 ? (
              <EmptyChart />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={54}
                    outerRadius={86}
                    paddingAngle={3}
                    stroke="var(--color-card)"
                    strokeWidth={2}
                  >
                    {pieData.map((d) => (
                      <Cell key={d.name} fill={d.fill} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTip />} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="flex flex-wrap gap-4 text-xs">
            {[
              { n: "Safe", c: "bg-safe" },
              { n: "Near expiry", c: "bg-warn" },
              { n: "Expired", c: "bg-danger" },
            ].map((l) => (
              <span key={l.n} className="inline-flex items-center gap-2 text-muted-foreground">
                <span className={cn("size-2.5 rounded-full", l.c)} />
                {l.n}
              </span>
            ))}
          </div>
        </div>

        <div className="panel panel-enter p-5 lg:col-span-7">
          <h3 className="text-base font-semibold">Upcoming expiration timeline</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Products grouped by days remaining
          </p>
          <div className="h-60">
            {products.length === 0 ? (
              <EmptyChart />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={timeline} margin={{ top: 16, right: 8, left: -20, bottom: 0 }}>
                  <XAxis
                    dataKey="label"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }}
                  />
                  <YAxis
                    allowDecimals={false}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }}
                  />
                  <Tooltip content={<ChartTip />} cursor={{ fill: "var(--color-muted)" }} />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                    {timeline.map((row, i) => (
                      <Cell
                        key={row.label}
                        fill={
                          i === 0
                            ? "var(--color-danger)"
                            : i <= 2
                              ? "var(--color-warn)"
                              : "var(--color-safe)"
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function EmptyChart() {
  return (
    <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
      No inventory yet — add a product or load sample data.
    </div>
  );
}

function ChartTip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ name?: string; value?: number; payload?: { label?: string } }>;
}) {
  if (!active || !payload?.length) return null;
  const item = payload[0];
  if (!item) return null;
  const label = item.payload?.label ?? item.name;
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md">
      <span className="font-medium">{label}</span>
      <span className="num ml-2">{item.value}</span>
    </div>
  );
}
