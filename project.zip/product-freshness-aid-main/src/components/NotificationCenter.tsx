import { useMemo, useState } from "react";
import { Bell, BellRing, CheckCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { LevelPill } from "@/components/StatusBadge";
import type { AppNotification, NotificationState } from "@/types/inventory";
import { cn } from "@/lib/utils";

interface Props {
  notifications: AppNotification[];
  state: NotificationState;
  onStateChange: (state: NotificationState) => void;
  onToggleBrowser: (enabled: boolean) => void;
}

type Tab = "all" | "expired" | "expiring";

export function NotificationCenter({
  notifications,
  state,
  onStateChange,
  onToggleBrowser,
}: Props) {
  const [tab, setTab] = useState<Tab>("all");

  const visible = useMemo(
    () => notifications.filter((n) => !state.dismissed.includes(n.id)),
    [notifications, state.dismissed],
  );
  const unread = visible.filter((n) => !state.read.includes(n.id));
  const list = visible.filter((n) => tab === "all" || n.level === tab);

  const tabs: Array<{ key: Tab; label: string; count: number }> = [
    { key: "all", label: "All", count: visible.length },
    { key: "expired", label: "Expired", count: visible.filter((n) => n.level === "expired").length },
    {
      key: "expiring",
      label: "Expiring soon",
      count: visible.filter((n) => n.level === "expiring").length,
    },
  ];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative" aria-label="Notifications">
          {unread.length > 0 ? <BellRing className="size-4" /> : <Bell className="size-4" />}
          {visible.length > 0 && (
            <span className="num absolute -top-1.5 -right-1.5 inline-flex min-w-5 items-center justify-center rounded-full bg-danger px-1 py-0.5 text-[10px] leading-none font-semibold text-danger-foreground">
              {visible.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[22rem] p-0 sm:w-96">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div>
            <p className="text-sm font-semibold">Alerts</p>
            <p className="text-xs text-muted-foreground">
              {unread.length} unread of {visible.length} active
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-xs"
            onClick={() =>
              onStateChange({ ...state, read: visible.map((n) => n.id) })
            }
          >
            <CheckCheck className="mr-1 size-3.5" />
            Mark all read
          </Button>
        </div>

        <div className="flex gap-1.5 border-b border-border px-3 py-2">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "rounded-full px-2.5 py-1 text-xs font-medium transition-colors",
                tab === t.key
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary",
              )}
            >
              {t.label}
              <span className="num ml-1 opacity-70">{t.count}</span>
            </button>
          ))}
        </div>

        <div className="max-h-80 overflow-y-auto">
          {list.length === 0 ? (
            <p className="px-4 py-10 text-center text-sm text-muted-foreground">
              Nothing needs attention here.
            </p>
          ) : (
            list.map((n) => {
              const isRead = state.read.includes(n.id);
              return (
                <div
                  key={n.id}
                  className={cn(
                    "flex gap-3 border-b border-border/70 px-4 py-3 last:border-0",
                    !isRead && "bg-secondary/50",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <LevelPill level={n.level}>
                        {n.level === "expired" ? "Expired" : "Expiring"}
                      </LevelPill>
                      {!isRead && <span className="size-1.5 rounded-full bg-primary" />}
                    </div>
                    <p className="mt-1.5 truncate text-sm font-medium">{n.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{n.message}</p>
                    {!isRead && (
                      <button
                        className="mt-1.5 text-xs font-medium text-primary hover:underline"
                        onClick={() => onStateChange({ ...state, read: [...state.read, n.id] })}
                      >
                        Mark as read
                      </button>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7 shrink-0"
                    aria-label="Dismiss notification"
                    onClick={() =>
                      onStateChange({ ...state, dismissed: [...state.dismissed, n.id] })
                    }
                  >
                    <X className="size-3.5" />
                  </Button>
                </div>
              );
            })
          )}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-4 py-3">
          <Label htmlFor="browser-alerts" className="text-xs text-muted-foreground">
            Browser notifications
          </Label>
          <Switch
            id="browser-alerts"
            checked={state.browserEnabled}
            onCheckedChange={onToggleBrowser}
          />
        </div>
      </PopoverContent>
    </Popover>
  );
}
