import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Product, ProductUnit } from "@/types/inventory";
import { addDaysISO, isValidDate, todayISO } from "@/utils/dateUtils";
import { newId } from "@/utils/inventoryStore";

const UNITS: ProductUnit[] = ["pcs", "kg", "g", "L", "boxes", "packs"];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product | null;
  onSave: (product: Product) => void;
}

type FormState = {
  name: string;
  sku: string;
  category: string;
  quantity: string;
  unit: ProductUnit;
  mfgDate: string;
  expiryDate: string;
  alertThreshold: string;
};

const blank = (): FormState => ({
  name: "",
  sku: "",
  category: "",
  quantity: "1",
  unit: "pcs",
  mfgDate: todayISO(),
  expiryDate: addDaysISO(60),
  alertThreshold: "30",
});

export function ProductModal({ open, onOpenChange, product, onSave }: Props) {
  const [form, setForm] = useState<FormState>(blank);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setForm(
      product
        ? {
            name: product.name,
            sku: product.sku,
            category: product.category,
            quantity: String(product.quantity),
            unit: product.unit,
            mfgDate: product.mfgDate,
            expiryDate: product.expiryDate,
            alertThreshold: String(product.alertThreshold),
          }
        : blank(),
    );
  }, [open, product]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  function submit() {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = "Product name is required";
    if (!form.sku.trim()) next.sku = "SKU is required";
    const qty = Number(form.quantity);
    if (!Number.isFinite(qty) || qty < 0) next.quantity = "Enter a quantity of 0 or more";
    if (!isValidDate(form.mfgDate)) next.mfgDate = "Use format YYYY-MM-DD";
    if (!isValidDate(form.expiryDate)) next.expiryDate = "Use format YYYY-MM-DD";
    if (
      isValidDate(form.mfgDate) &&
      isValidDate(form.expiryDate) &&
      form.expiryDate < form.mfgDate
    ) {
      next.expiryDate = "Expiry cannot be before manufacture date";
    }
    const threshold = Number(form.alertThreshold);
    if (!Number.isFinite(threshold) || threshold < 0) next.alertThreshold = "Enter days ≥ 0";

    setErrors(next);
    if (Object.keys(next).length > 0) return;

    onSave({
      id: product?.id ?? newId(),
      createdAt: product?.createdAt ?? new Date().toISOString(),
      name: form.name.trim(),
      sku: form.sku.trim().toUpperCase(),
      category: form.category.trim() || "Uncategorised",
      quantity: qty,
      unit: form.unit,
      mfgDate: form.mfgDate,
      expiryDate: form.expiryDate,
      alertThreshold: threshold,
    });
    onOpenChange(false);
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col gap-0 sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>{product ? "Edit product" : "Add product"}</SheetTitle>
          <SheetDescription>
            Shelf-life is calculated from the expiry date and the alert threshold.
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 space-y-4 overflow-y-auto px-4 pb-4">
          <Field label="Product name" error={errors.name}>
            <Input
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="Whole Milk 1L"
            />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="SKU" error={errors.sku}>
              <Input
                value={form.sku}
                onChange={(e) => set("sku", e.target.value)}
                placeholder="DAI-1001"
              />
            </Field>
            <Field label="Category">
              <Input
                value={form.category}
                onChange={(e) => set("category", e.target.value)}
                placeholder="Dairy"
              />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Quantity in stock" error={errors.quantity}>
              <Input
                type="number"
                min={0}
                value={form.quantity}
                onChange={(e) => set("quantity", e.target.value)}
              />
            </Field>
            <Field label="Unit">
              <Select value={form.unit} onValueChange={(v) => set("unit", v as ProductUnit)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {UNITS.map((u) => (
                    <SelectItem key={u} value={u}>
                      {u}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Manufactured date" error={errors.mfgDate}>
              <Input
                type="date"
                value={form.mfgDate}
                onChange={(e) => set("mfgDate", e.target.value)}
              />
            </Field>
            <Field label="Expiry date" error={errors.expiryDate}>
              <Input
                type="date"
                value={form.expiryDate}
                onChange={(e) => set("expiryDate", e.target.value)}
              />
            </Field>
          </div>

          <Field
            label="Alert threshold (days before expiry)"
            error={errors.alertThreshold}
            hint="Default 30 days"
          >
            <Input
              type="number"
              min={0}
              value={form.alertThreshold}
              onChange={(e) => set("alertThreshold", e.target.value)}
            />
          </Field>
        </div>

        <SheetFooter className="flex-row justify-end gap-2 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit}>{product ? "Save changes" : "Add product"}</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function Field({
  label,
  error,
  hint,
  children,
}: {
  label: string;
  error?: string | undefined;
  hint?: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
      {error ? (
        <p className="text-xs text-danger">{error}</p>
      ) : hint ? (
        <p className="text-xs text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  );
}
