import { ArrowDown, ArrowUp, ArrowUpDown, Minus, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import type { FilterOptions, Product, SortKey, StatusFilter } from "@/types/inventory";
import { daysRemaining, formatDate, getStatus } from "@/utils/dateUtils";
import { cn } from "@/lib/utils";

interface Props {
  products: Product[];
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  onEdit: (product: Product) => void;
  onDelete: (id: string) => void;
  onAdjustStock: (id: string, delta: number) => void;
}

const STATUS_TABS: Array<{ key: StatusFilter; label: string }> = [
  { key: "all", label: "All" },
  { key: "expired", label: "Expired" },
  { key: "expiring", label: "Expiring soon" },
  { key: "safe", label: "Healthy / safe" },
];

const COLUMNS: Array<{ key: SortKey | null; label: string; className?: string }> = [
  { key: "name", label: "Product" },
  { key: "quantity", label: "Stock" },
  { key: "mfgDate", label: "Manufactured" },
  { key: "expiryDate", label: "Expiry" },
  { key: "daysRemaining", label: "Days remaining" },
  { key: null, label: "Status" },
  { key: null, label: "Actions", className: "text-right" },
];

export function ProductTable({
  products,
  filters,
  onFiltersChange,
  onEdit,
  onDelete,
  onAdjustStock,
}: Props) {
  const rows = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    const filtered = products.filter((p) => {
      const matches =
        !q || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
      const statusOk = filters.status === "all" || getStatus(p) === filters.status;
      return matches && statusOk;
    });
    const dir = filters.sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      switch (filters.sortKey) {
        case "name":
          return a.name.localeCompare(b.name) * dir;
        case "quantity":
          return (a.quantity - b.quantity) * dir;
        case "mfgDate":
          return a.mfgDate.localeCompare(b.mfgDate) * dir;
        case "expiryDate":
          return a.expiryDate.localeCompare(b.expiryDate) * dir;
        default:
          return (daysRemaining(a.expiryDate) - daysRemaining(b.expiryDate)) * dir;
      }
    });
  }, [products, filters]);

  function sortBy(key: SortKey) {
    onFiltersChange({
      ...filters,
      sortKey: key,
      sortDir: filters.sortKey === key && filters.sortDir === "asc" ? "desc" : "asc",
    });
  }

  const counts = useMemo(
    () => ({
      all: products.length,
      expired: products.filter((p) => getStatus(p) === "expired").length,
      expiring: products.filter((p) => getStatus(p) === "expiring").length,
      safe: products.filter((p) => getStatus(p) === "safe").length,
    }),
    [products],
  );

  return (
    <section className="panel panel-enter overflow-hidden">
      <div className="flex flex-col gap-3 border-b border-border p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full lg:max-w-xs">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={filters.search}
            onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
            placeholder="Search by product name or SKU"
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {STATUS_TABS.map((t) => (
            <Button
              key={t.key}
              variant="ghost"
              size="sm"
              onClick={() => onFiltersChange({ ...filters, status: t.key })}
              className={cn(
                "h-8 rounded-full border px-3 text-xs font-medium transition-colors",
                filters.status === t.key
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:bg-secondary",
              )}
            >
              {t.label}
              <span className="num ml-1.5 opacity-70">{counts[t.key]}</span>
            </Button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[920px] text-sm">
          <thead>
            <tr className="border-b border-border bg-secondary/60">
              {COLUMNS.map((c) => (
                <th
                  key={c.label}
                  className={cn(
                    "px-4 py-3 text-left text-xs font-semibold tracking-wide text-muted-foreground uppercase",
                    c.className,
                  )}
                >
                  {c.key ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (c.key) sortBy(c.key);
                      }}
                      className="h-auto gap-1 p-0 text-xs font-semibold uppercase hover:bg-transparent"
                    >
                      {c.label}
                      {filters.sortKey === c.key ? (
                        filters.sortDir === "asc" ? (
                          <ArrowUp className="size-3" />
                        ) : (
                          <ArrowDown className="size-3" />
                        )
                      ) : (
                        <ArrowUpDown className="size-3 opacity-50" />
                      )}
                    </Button>
                  ) : (
                    c.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={COLUMNS.length} className="px-4 py-14 text-center text-muted-foreground">
                  No products match the current search or filter.
                </td>
              </tr>
            ) : (
              rows.map((p) => {
                const days = daysRemaining(p.expiryDate);
                return (
                  <tr key={p.id} className="border-b border-border/70 last:border-0 hover:bg-secondary/40">
                    <td className="px-4 py-3">
                      <p className="font-medium">{p.name}</p>
                      <p className="num mt-0.5 text-xs text-muted-foreground">
                        {p.sku} · {p.category}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <span className="num font-medium">{p.quantity}</span>
                      <span className="ml-1 text-xs text-muted-foreground">{p.unit}</span>
                    </td>
                    <td className="num px-4 py-3 text-muted-foreground">{formatDate(p.mfgDate)}</td>
                    <td className="num px-4 py-3">{formatDate(p.expiryDate)}</td>
                    <td className="num px-4 py-3">
                      {days < 0 ? `−${Math.abs(days)}` : days}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge product={p} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <div className="mr-1 flex items-center rounded-lg border border-border">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 rounded-r-none"
                            aria-label={`Decrease stock of ${p.name}`}
                            onClick={() => onAdjustStock(p.id, -1)}
                          >
                            <Minus className="size-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 rounded-l-none border-l border-border"
                            aria-label={`Increase stock of ${p.name}`}
                            onClick={() => onAdjustStock(p.id, 1)}
                          >
                            <Plus className="size-3.5" />
                          </Button>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8"
                          aria-label={`Edit ${p.name}`}
                          onClick={() => onEdit(p)}
                        >
                          <Pencil className="size-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8 text-danger hover:text-danger"
                          aria-label={`Delete ${p.name}`}
                          onClick={() => onDelete(p.id)}
                        >
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
