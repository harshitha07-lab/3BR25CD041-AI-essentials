import { AlertTriangle, CheckCircle2, Clock, XCircle } from "lucide-react";
import type { Product, ProductStatus } from "@/types/inventory";
import { daysRemaining, getStatus, statusLabel } from "@/utils/dateUtils";
import { cn } from "@/lib/utils";

const tone: Record<ProductStatus, string> = {
  expired: "bg-danger-soft text-danger border-danger/25",
  expiring: "bg-warn-soft text-warn-foreground border-warn/35",
  safe: "bg-safe-soft text-safe border-safe/25",
};

export function StatusBadge({
  product,
  className,
}: {
  product: Product;
  className?: string;
}) {
  const status = getStatus(product);
  const days = daysRemaining(product.expiryDate);
  const Icon =
    status === "expired" ? XCircle : status === "expiring" ? AlertTriangle : CheckCircle2;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium whitespace-nowrap",
        tone[status],
        className,
      )}
    >
      <Icon className="size-3.5 shrink-0" />
      {status === "safe" ? `Safe · ${days} days left` : statusLabel(product)}
    </span>
  );
}

export function LevelPill({
  level,
  children,
}: {
  level: ProductStatus;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide uppercase",
        tone[level],
      )}
    >
      <Clock className="size-3" />
      {children}
    </span>
  );
}
