import { Image, Pause, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";

export interface WallpaperSettings {
  opacity: number;
  speed: number;
  paused: boolean;
}

interface WallpaperControlsProps {
  settings: WallpaperSettings;
  onSettingsChange: (settings: WallpaperSettings) => void;
}

export function WallpaperControls({ settings, onSettingsChange }: WallpaperControlsProps) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" aria-label="Wallpaper settings" title="Wallpaper settings">
          <Image className="size-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 space-y-5">
        <div>
          <h2 className="text-sm font-semibold">Wallpaper</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">Adjust the supermarket backdrop.</p>
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3 text-xs">
            <label htmlFor="wallpaper-opacity" className="font-medium">Opacity</label>
            <output className="num text-muted-foreground">{settings.opacity}%</output>
          </div>
          <Slider
            id="wallpaper-opacity"
            min={5}
            max={30}
            step={5}
            value={[settings.opacity]}
            onValueChange={([opacity]) => {
              if (opacity !== undefined) onSettingsChange({ ...settings, opacity });
            }}
            aria-label="Wallpaper opacity"
          />
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3 text-xs">
            <label htmlFor="wallpaper-speed" className="font-medium">Motion speed</label>
            <output className="num text-muted-foreground">{settings.speed}s</output>
          </div>
          <Slider
            id="wallpaper-speed"
            min={8}
            max={48}
            step={4}
            value={[settings.speed]}
            onValueChange={([speed]) => {
              if (speed !== undefined) onSettingsChange({ ...settings, speed });
            }}
            aria-label="Wallpaper animation duration"
          />
          <p className="text-[11px] text-muted-foreground">Fewer seconds means faster motion.</p>
        </div>

        <Button
          variant={settings.paused ? "secondary" : "outline"}
          size="sm"
          className="w-full"
          onClick={() => onSettingsChange({ ...settings, paused: !settings.paused })}
          aria-pressed={settings.paused}
        >
          {settings.paused ? <Play /> : <Pause />}
          {settings.paused ? "Resume motion" : "Pause motion"}
        </Button>
      </PopoverContent>
    </Popover>
  );
}