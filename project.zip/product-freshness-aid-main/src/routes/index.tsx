import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Download, PackagePlus, Sparkles, Trash, Upload, WandSparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dashboard } from "@/components/Dashboard";
import { ProductTable } from "@/components/ProductTable";
import { ProductModal } from "@/components/ProductModal";
import { NotificationCenter } from "@/components/NotificationCenter";
import { CsvUploader } from "@/components/CsvUploader";
import type { FilterOptions, NotificationState, Product } from "@/types/inventory";
import {
  buildNotifications,
  emptyNotificationState,
  loadNotificationState,
  loadProducts,
  sampleProducts,
  saveNotificationState,
  saveProducts,
  toCsv,
} from "@/utils/inventoryStore";
import { todayISO } from "@/utils/dateUtils";
import supermarketWatermark from "@/assets/supermarket-watermark.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Shelf Sentinel — Product Shelf-Life & Inventory Tracker" },
      {
        name: "description",
        content:
          "Track product expiry dates, stock levels and shelf-life alerts. Bulk import CSV inventory, monitor near-expiry items and export status reports.",
      },
      { property: "og:title", content: "Shelf Sentinel — Shelf-Life & Inventory Tracker" },
      {
        property: "og:description",
        content:
          "Expiry health dashboard, smart alerts and CSV bulk import for perishable and pharmaceutical inventory.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [products, setProducts] = useState<Product[]>([]);
  const [notifState, setNotifState] = useState<NotificationState>(emptyNotificationState);
  const [hydrated, setHydrated] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [uploaderOpen, setUploaderOpen] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    search: "",
    status: "all",
    sortKey: "daysRemaining",
    sortDir: "asc",
  });

  useEffect(() => {
    setProducts(loadProducts());
    setNotifState(loadNotificationState());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveProducts(products);
  }, [products, hydrated]);

  useEffect(() => {
    if (hydrated) saveNotificationState(notifState);
  }, [notifState, hydrated]);

  const notifications = useMemo(() => buildNotifications(products), [products]);
  const activeAlerts = notifications.filter((n) => !notifState.dismissed.includes(n.id));

  // Fire native browser notifications once per session when alerts exist.
  useEffect(() => {
    if (!hydrated || !notifState.browserEnabled || activeAlerts.length === 0) return;
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const flag = `shelflife.notified.${todayISO()}`;
    if (window.sessionStorage.getItem(flag)) return;
    window.sessionStorage.setItem(flag, "1");
    const expired = activeAlerts.filter((n) => n.level === "expired").length;
    new Notification("Shelf Sentinel: inventory needs attention", {
      body: `${expired} expired · ${activeAlerts.length - expired} expiring soon`,
    });
  }, [hydrated, notifState.browserEnabled, activeAlerts]);

  const toggleBrowser = useCallback(async (enabled: boolean) => {
    if (!enabled) {
      setNotifState((s) => ({ ...s, browserEnabled: false }));
      return;
    }
    if (typeof Notification === "undefined") {
      toast.error("This browser does not support notifications.");
      return;
    }
    const permission =
      Notification.permission === "granted"
        ? "granted"
        : await Notification.requestPermission();
    if (permission !== "granted") {
      toast.error("Notification permission was blocked in your browser settings.");
      return;
    }
    setNotifState((s) => ({ ...s, browserEnabled: true }));
    toast.success("Browser alerts enabled.");
  }, []);

  function saveProduct(product: Product) {
    setProducts((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      return exists ? prev.map((p) => (p.id === product.id ? product : p)) : [product, ...prev];
    });
    toast.success(editing ? "Product updated." : "Product added.");
  }

  function exportCsv() {
    if (products.length === 0) {
      toast.error("Nothing to export yet.");
      return;
    }
    const blob = new Blob([toCsv(products)], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `inventory-${todayISO()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Inventory exported.");
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none fixed inset-x-0 top-0 h-[28rem] overflow-hidden" aria-hidden="true">
        <img
          src={supermarketWatermark}
          alt=""
          width={1920}
          height={768}
          className="watermark-drift h-full w-[108%] max-w-none object-cover opacity-[0.78] saturate-110"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/20 to-background/80" />
      </div>

      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-4 sm:px-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <span className="gentle-float inline-flex size-11 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/20">
              <WandSparkles className="size-5" />
            </span>
            <div>
              <h1 className="text-xl leading-tight font-semibold">Shelf Sentinel</h1>
              <p className="text-xs text-muted-foreground">
                Product shelf-life &amp; inventory tracker
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <NotificationCenter
              notifications={notifications}
              state={notifState}
              onStateChange={setNotifState}
              onToggleBrowser={toggleBrowser}
            />
            <Button variant="outline" size="sm" onClick={() => setUploaderOpen(true)}>
              <Upload className="mr-1.5 size-4" />
              Import CSV
            </Button>
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="mr-1.5 size-4" />
              Export CSV
            </Button>
            <Button
              size="sm"
              onClick={() => {
                setEditing(null);
                setModalOpen(true);
              }}
            >
              <PackagePlus className="mr-1.5 size-4" />
              Add product
            </Button>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-7xl space-y-5 px-4 py-7 sm:px-6">
        <div className="panel panel-enter flex flex-wrap items-center justify-between gap-4 overflow-hidden p-5 sm:p-6">
          <div>
            <p className="mb-1 text-xs font-bold tracking-[0.16em] text-primary uppercase">Today’s overview</p>
            <h2 className="text-2xl font-semibold sm:text-3xl">Expiration health</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {products.length === 0
                ? "No inventory yet — load sample data to explore the tracker."
                : `${activeAlerts.length} product${activeAlerts.length === 1 ? "" : "s"} need attention today.`}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setProducts(sampleProducts());
                setNotifState((s) => ({ ...s, read: [], dismissed: [] }));
                toast.success("Sample inventory loaded.");
              }}
            >
              <Sparkles className="mr-1.5 size-4" />
              Load sample data
            </Button>
            {products.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-danger hover:text-danger"
                onClick={() => {
                  setProducts([]);
                  setNotifState((s) => ({ ...s, read: [], dismissed: [] }));
                  toast.success("Inventory cleared.");
                }}
              >
                <Trash className="mr-1.5 size-4" />
                Clear all
              </Button>
            )}
          </div>
        </div>

        <div className="grid gap-5 xl:grid-cols-12">
          <div className="xl:col-span-12">
            <Dashboard products={products} />
          </div>
          <div className="xl:col-span-12">
            <ProductTable
              products={products}
              filters={filters}
              onFiltersChange={setFilters}
              onEdit={(p) => {
                setEditing(p);
                setModalOpen(true);
              }}
              onDelete={(id) => {
                setProducts((prev) => prev.filter((p) => p.id !== id));
                toast.success("Product deleted.");
              }}
              onAdjustStock={(id, delta) =>
                setProducts((prev) =>
                  prev.map((p) =>
                    p.id === id ? { ...p, quantity: Math.max(0, p.quantity + delta) } : p,
                  ),
                )
              }
            />
          </div>
        </div>
      </main>

      <ProductModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        product={editing}
        onSave={saveProduct}
      />
      <CsvUploader
        open={uploaderOpen}
        onOpenChange={setUploaderOpen}
        onImport={(imported) => {
          setProducts((prev) => [...imported, ...prev]);
          toast.success(`${imported.length} products imported.`);
        }}
      />
    </div>
  );
}
