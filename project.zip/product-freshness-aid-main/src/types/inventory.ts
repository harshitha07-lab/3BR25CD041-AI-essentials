export type ProductUnit = "pcs" | "kg" | "g" | "L" | "boxes" | "packs";

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  unit: ProductUnit;
  mfgDate: string; // YYYY-MM-DD
  expiryDate: string; // YYYY-MM-DD
  alertThreshold: number; // days before expiry
  createdAt: string;
}

export type ProductStatus = "expired" | "expiring" | "safe";

export type StatusFilter = "all" | ProductStatus;

export type SortKey = "name" | "quantity" | "mfgDate" | "expiryDate" | "daysRemaining";

export interface FilterOptions {
  search: string;
  status: StatusFilter;
  sortKey: SortKey;
  sortDir: "asc" | "desc";
}

export interface AppNotification {
  id: string;
  productId: string;
  level: Exclude<ProductStatus, "safe">;
  title: string;
  message: string;
  createdAt: string;
}

export interface NotificationState {
  read: string[];
  dismissed: string[];
  browserEnabled: boolean;
}

export interface ParsedRow {
  row: number;
  product: Product | null;
  errors: string[];
  raw: Record<string, string>;
}
