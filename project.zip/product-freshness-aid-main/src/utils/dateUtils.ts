import type { Product, ProductStatus } from "@/types/inventory";

const MS_PER_DAY = 86_400_000;

/** Midnight-normalised timestamp for a YYYY-MM-DD string. */
function parts(date: string): [number, number, number] {
  const [y, m, d] = date.split("-").map(Number);
  return [y ?? 1970, m ?? 1, d ?? 1];
}

function dayStamp(date: string): number {
  const [y, m, d] = parts(date);
  return Date.UTC(y, m - 1, d);
}

function todayStamp(): number {
  const now = new Date();
  return Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
}

export function isValidDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = parts(value);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d
  );
}

/** Negative means already expired. */
export function daysRemaining(expiryDate: string): number {
  return Math.round((dayStamp(expiryDate) - todayStamp()) / MS_PER_DAY);
}

export function getStatus(product: Product): ProductStatus {
  const days = daysRemaining(product.expiryDate);
  if (days < 0) return "expired";
  if (days <= (product.alertThreshold || 30)) return "expiring";
  return "safe";
}

export function statusLabel(product: Product): string {
  const days = daysRemaining(product.expiryDate);
  if (days < 0) {
    const n = Math.abs(days);
    return `Expired ${n} day${n === 1 ? "" : "s"} ago`;
  }
  if (days === 0) return "Expires today";
  return `Expires in ${days} day${days === 1 ? "" : "s"}`;
}

export function formatDate(value: string): string {
  if (!isValidDate(value)) return value;
  const [y, m, d] = parts(value);
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  });
}

export function todayISO(): string {
  return new Date(todayStamp()).toISOString().slice(0, 10);
}

export function addDaysISO(days: number): string {
  return new Date(todayStamp() + days * MS_PER_DAY).toISOString().slice(0, 10);
}

/** Normalises common spreadsheet date shapes into YYYY-MM-DD. */
export function normaliseDate(input: string): string | null {
  const value = (input ?? "").trim();
  if (!value) return null;
  if (isValidDate(value)) return value;
  const slash = value.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (slash) {
    const a = slash[1] ?? "";
    const b = slash[2] ?? "";
    const y = slash[3] ?? "";
    const day = Number(a) > 12 ? a : b;
    const month = Number(a) > 12 ? b : a;
    const iso = `${y}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    return isValidDate(iso) ? iso : null;
  }
  const parsed = new Date(value);
  if (!Number.isNaN(parsed.getTime())) {
    return parsed.toISOString().slice(0, 10);
  }
  return null;
}
