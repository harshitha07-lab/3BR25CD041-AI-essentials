import type { AppNotification, NotificationState, Product } from "@/types/inventory";
import { addDaysISO, daysRemaining, getStatus, statusLabel } from "./dateUtils";

export const PRODUCTS_KEY = "shelflife.products.v1";
export const NOTIFICATIONS_KEY = "shelflife.notifications.v1";

export const emptyNotificationState: NotificationState = {
  read: [],
  dismissed: [],
  browserEnabled: false,
};

export function loadProducts(): Product[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(PRODUCTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Product[]) : [];
  } catch {
    return [];
  }
}

export function saveProducts(products: Product[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
}

export function loadNotificationState(): NotificationState {
  if (typeof window === "undefined") return emptyNotificationState;
  try {
    const raw = window.localStorage.getItem(NOTIFICATIONS_KEY);
    if (!raw) return emptyNotificationState;
    return { ...emptyNotificationState, ...JSON.parse(raw) };
  } catch {
    return emptyNotificationState;
  }
}

export function saveNotificationState(state: NotificationState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(state));
}

export function newId(): string {
  return `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function buildNotifications(products: Product[]): AppNotification[] {
  return products
    .filter((p) => getStatus(p) !== "safe")
    .map((p) => {
      const level = getStatus(p) === "expired" ? "expired" : "expiring";
      return {
        id: `${p.id}:${p.expiryDate}:${level}`,
        productId: p.id,
        level,
        title: p.name,
        message: `${statusLabel(p)} · ${p.quantity} ${p.unit} in stock · SKU ${p.sku}`,
        createdAt: new Date().toISOString(),
      } satisfies AppNotification;
    })
    .sort((a, b) => {
      const pa = products.find((p) => p.id === a.productId)!;
      const pb = products.find((p) => p.id === b.productId)!;
      return daysRemaining(pa.expiryDate) - daysRemaining(pb.expiryDate);
    });
}

export function toCsv(products: Product[]): string {
  const header = [
    "Product Name",
    "SKU",
    "Category",
    "Quantity",
    "Unit",
    "Mfg Date",
    "Expiry Date",
    "Alert Threshold",
    "Days Remaining",
    "Status",
  ];
  const escape = (v: string | number) => {
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows = products.map((p) =>
    [
      p.name,
      p.sku,
      p.category,
      p.quantity,
      p.unit,
      p.mfgDate,
      p.expiryDate,
      p.alertThreshold,
      daysRemaining(p.expiryDate),
      getStatus(p),
    ]
      .map(escape)
      .join(","),
  );
  return [header.join(","), ...rows].join("\n");
}

export function sampleProducts(): Product[] {
  const base: Array<Omit<Product, "id" | "createdAt">> = [
    { name: "Whole Milk 1L", sku: "DAI-1001", category: "Dairy", quantity: 48, unit: "L", mfgDate: addDaysISO(-6), expiryDate: addDaysISO(-2), alertThreshold: 7 },
    { name: "Greek Yogurt 500g", sku: "DAI-1042", category: "Dairy", quantity: 120, unit: "pcs", mfgDate: addDaysISO(-10), expiryDate: addDaysISO(4), alertThreshold: 7 },
    { name: "Aged Cheddar Block", sku: "DAI-1180", category: "Dairy", quantity: 26, unit: "kg", mfgDate: addDaysISO(-60), expiryDate: addDaysISO(120), alertThreshold: 30 },
    { name: "Amoxicillin 500mg", sku: "PHA-2201", category: "Pharmaceutical", quantity: 340, unit: "boxes", mfgDate: addDaysISO(-400), expiryDate: addDaysISO(18), alertThreshold: 30 },
    { name: "Paracetamol Syrup", sku: "PHA-2288", category: "Pharmaceutical", quantity: 90, unit: "pcs", mfgDate: addDaysISO(-200), expiryDate: addDaysISO(-14), alertThreshold: 30 },
    { name: "Insulin Vials", sku: "PHA-2410", category: "Pharmaceutical", quantity: 58, unit: "packs", mfgDate: addDaysISO(-45), expiryDate: addDaysISO(26), alertThreshold: 45 },
    { name: "Sourdough Loaf", sku: "BAK-3011", category: "Bakery", quantity: 64, unit: "pcs", mfgDate: addDaysISO(-1), expiryDate: addDaysISO(2), alertThreshold: 5 },
    { name: "Croissant Tray", sku: "BAK-3077", category: "Bakery", quantity: 36, unit: "boxes", mfgDate: addDaysISO(-2), expiryDate: addDaysISO(1), alertThreshold: 5 },
    { name: "Canned Chickpeas", sku: "PKG-4100", category: "Packaged Goods", quantity: 520, unit: "pcs", mfgDate: addDaysISO(-180), expiryDate: addDaysISO(400), alertThreshold: 30 },
    { name: "Olive Oil 5L", sku: "PKG-4155", category: "Packaged Goods", quantity: 88, unit: "L", mfgDate: addDaysISO(-90), expiryDate: addDaysISO(240), alertThreshold: 30 },
    { name: "Frozen Berries", sku: "FRZ-5020", category: "Frozen", quantity: 150, unit: "kg", mfgDate: addDaysISO(-70), expiryDate: addDaysISO(60), alertThreshold: 30 },
    { name: "Fresh Salmon Fillet", sku: "SEA-6001", category: "Seafood", quantity: 22, unit: "kg", mfgDate: addDaysISO(-2), expiryDate: addDaysISO(0), alertThreshold: 5 },
    { name: "Baby Formula Stage 1", sku: "INF-7003", category: "Infant", quantity: 210, unit: "boxes", mfgDate: addDaysISO(-150), expiryDate: addDaysISO(29), alertThreshold: 45 },
    { name: "Vitamin D Drops", sku: "PHA-2506", category: "Pharmaceutical", quantity: 75, unit: "pcs", mfgDate: addDaysISO(-300), expiryDate: addDaysISO(-40), alertThreshold: 30 },
    { name: "Basmati Rice 10kg", sku: "PKG-4290", category: "Packaged Goods", quantity: 300, unit: "boxes", mfgDate: addDaysISO(-120), expiryDate: addDaysISO(600), alertThreshold: 30 },
  ];
  return base.map((p) => ({ ...p, id: newId(), createdAt: new Date().toISOString() }));
}
